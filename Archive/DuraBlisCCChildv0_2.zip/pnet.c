/* File:   pnet.c  Pnet comm stack.
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX130F064B
 * Created: 25 Jun 14
 * PNet version 'A' here
 */

#include <xc.h>
#include "DuraBlisChild.h"
#include "pnet.h"

extern byte pnetNodeNumber;
extern byte sysStat;

    // --------------------------
void assignNodeNumber(byte childNodeNumberOld, byte childNodeNumber)
{
    extern byte pnetNodeNumber;
    if (childNodeNumberOld == pnetNodeNumber)
    {
        pnetNodeNumber = childNodeNumber;
        //putPrompt();
        putStr("prak");
        putChar('0' + childNodeNumberOld);
        putChar('0' + childNodeNumber);
         putChar('\r');
    }
    else return;
}

    // Input syntax:                                State Mach
    // AT n         ak n v ss                       10
    // T? n         tk n 095.6  atof-able, Fahr     20
    // H? n         hk n 023.4  rel hum, 0 - 100    30
    // V n a|b +|-  vk n a|b +|-                    40
    // V? n         v n a|b +|-                     45
    // RESET                                        50
    // UID? n       uid n U(10)                     60
    // PUID n U(10) puak n U(10)                    70

    // TODO timeout
    // TODO the putPrompt()'s here are solely for emulation
    // Refer to PNet Communication Protocol doc
void childStateMach(char charCh)   // Child emulation
{
    static unsigned int stMach = 0;
    static byte nodeNumber;  //, nodeNumberOld;
    static char relayName;

    switch(stMach)
    {
        case 0:
            if (charCh == 'A') stMach = 10;           
            else if (charCh == 'T') stMach = 20;
            else if (charCh == 'H') stMach = 30;
            else if (charCh == 'V') stMach = 40; 
            else if (charCh == 'R') stMach = 50;
            else if (charCh == 'U') stMach = 60;
            else if (charCh == 'P') stMach = 70;
            break;

        case 10:        // Reading A messages
             if (charCh == 'T') stMach = 11;
             else stMach = 0;
             break;

        case 11:
            if (charCh > '0' && charCh < '9')
            {
                nodeNumber = charCh - '0';
                respondAttention(nodeNumber);       // respond functions will decode
            }                                       // node number and act appropriately
            stMach = 0;     // Terminus
            break;

        case 20:        // Reading T messages
             if (charCh == '?') stMach = 21;
             else stMach = 0;
             break;

        case 21:           
            if (charCh > '0' && charCh < '9')
            {
                nodeNumber = charCh - '0';
                respondTemperature(nodeNumber);
            }
            stMach = 0;     // Terminus
            break;

        case 30:        // Reading H messages
             if (charCh == '?') stMach = 31;
             else stMach = 0;
             break;

        case 31:           
            if (charCh > '0' && charCh < '9')
            {
                nodeNumber = charCh - '0';
                respondRHumidity(nodeNumber);
            }
            stMach = 0;     // Terminus
            break;

        case 40:        // Reading V service requests            
            if (charCh > '0' && charCh < '9')
            {
                stMach = 41;
                nodeNumber = charCh - '0';
            }
            else if (charCh == '?') stMach = 45;
            else stMach = 0;
            break;

        case 41:
            if (charCh == 'a' || charCh == 'b')
            {
                stMach = 42;
                relayName = charCh;  
            }
            else stMach = 0;
            break;

        case 42:           
            if (charCh == '+') respondServiceRequest(nodeNumber, relayName, '+');
            else if (charCh == '-') respondServiceRequest(nodeNumber, relayName, '-');       
            stMach = 0;     // Terminus
            break;

        case 45:
            if (charCh > '0' && charCh < '9')
            {
                nodeNumber = charCh - '0';
                respondServiceQuery(nodeNumber);
            }
            stMach = 0;     // Terminus
            break;

        case 50:
            if (charCh == 'E') stMach = 51;
            else stMach = 0;
            break;

        case 51:
            if (charCh == 'S') stMach = 52;
            else stMach = 0;
            break;

        case 52:
            if (charCh == 'E') stMach = 53;
            else stMach = 0;
            break;

        case 53:
            if (charCh == 'T')
            {
                SYSKEY = 0xAA996655;
                SYSKEY = 0x556699AA;
                RSWRSTbits.SWRST = 1;
                while(1);       // Seppuku
            }
            stMach = 0;
            break;

        default:
            stMach = 0;     // Any syntax error resets
    }
}

     // ---------------------------
//void childReportInfo(void)
//{
//    putStr("\n\r Child node setting: ");
//    putChar('0' + pnetNodeNumber);
//    putStr("\n\r Child Eq word: ");
//    putUns2Hex(childEqWord);
//    putChar('h');
//    putStr("\n\r Child status: ");
//    putUns2Hex(childStatus);
//    putChar('h');
//}

    // ---------------------------
    // Screen unacceptable combos.
//bool realityCheckEq(byte newEqWord)
//{
//    byte sum = 0;
//    if ((newEqWord & CHILD_EQPT_TH_OUTSIDE) && (newEqWord & CHILD_EQPT_TH_INTFAN)) return false;
//    if (newEqWord & CHILD_EQPT_DEHUM_K1) sum++;
//    if (newEqWord & CHILD_EQPT_EXTFAN_K1) sum++;
//    if (newEqWord & CHILD_EQPT_HUMIDIFIER_K1) sum++;
//    if (sum > 1) return false;
//    sum = 0;
//    if (newEqWord & CHILD_EQPT_DEHUM_K2) sum++;
//    if (newEqWord & CHILD_EQPT_EXTFAN_K2) sum++;
//    if (newEqWord & CHILD_EQPT_HUMIDIFIER_K2) sum++;
//    if (sum > 1) return false;
//    return true;
//}

    // ---------------------------
void respondAttention(byte ch)
{   
    extern char pnetCommProtocolVer;
    
    if (ch == pnetNodeNumber)
    {
        //putPrompt();
        putStr("ak");
        putChar('0' + pnetNodeNumber);
        putChar(pnetCommProtocolVer);
        sprintf(ioBfr, "%02X\r", sysStat);
        putStr(ioBfr);
//        putNib2Hex(childEqWord >> 8);
//        putNib2Hex(childEqWord >> 4);
//        putNib2Hex(childEqWord);
        //putChar('\r');
      // putPrompt();
    }
}

    // ---------------------------
void respondRHumidity(byte ch)
{
    extern double rhumidNow;

    if (ch == pnetNodeNumber)
    {  
        putStr("hk");
        putChar('0' + pnetNodeNumber);
        if (sysStat & ST_HSEN_OKAY)
        {            
            sprintf(ioBfr, "%04.1f\r", rhumidNow);
            putStr(ioBfr);
        }
        else
        {
            putStr("ir\r");
        }
       // putChar('\r');
    }
}

    // --------------------------
void respondServiceQuery(byte ch)
{
    if (ch == pnetNodeNumber)
    {     
        putChar('v');
        putChar('0' + pnetNodeNumber);
        putChar('a');
        if (sysStat & ST_K1_ON) putChar('+');
        else putChar('-');
        putChar('b');
        if (sysStat & ST_K2_ON) putChar('+');
        else putChar('-');
        putChar('\r');
    }
}

    // ------------------------
void respondServiceRequest(byte ch, char relayNo, char onOff)
{   
    if (ch == pnetNodeNumber)
    {
        putStr("vk");
        putChar('0' + pnetNodeNumber);
        if (relayNo == 'a')
        {
            if (onOff == '+')
            {
                sysStat |= ST_K1_ON;
                RELAY1 = 1;
                putStr("a+\r");
            }
            else
            {
                sysStat &= ~ST_K1_ON;
                RELAY1 = 0;
                putStr("a-\r");
            }
        }
        else if (relayNo == 'b')
        {
            if (onOff == '+')
            {
                sysStat |= ST_K2_ON;
                RELAY2 = 1;
                putStr("b+\r");
            }
            else
            {
                sysStat &= ~ST_K2_ON;
                RELAY2 = 0;
                putStr("b-\r");
            }
        }       
    }
}

   
    // ---------------------------
void respondTemperature(byte ch)
{
    extern double temperNowF;

    if (ch == pnetNodeNumber)
    {
        putStr("tk");
        putChar('0' + pnetNodeNumber);
        if (sysStat & ST_HSEN_OKAY)
        {
            sprintf(ioBfr, "%04.1f", temperNowF);
            putStr(ioBfr);
        }
        else
        {
            putStr("ir");
        }
        putChar('\r');
    }
    else return;
}

//
//  case 23:
//            if (charCh == 'P') stMach = 24;
//            else stMach = 0;
//            break;
//
//        case 24:
//            if (charCh == 'R') stMach = 25;
//            else stMach = 0;
//            break;
//
//        case 25:
//            if (charCh >= '0' && charCh < '9')  // Sic
//            {
//                stMach = 26;
//                childNodeNumber = charCh - '0';
//            }
//            else stMach = 0;
//            break;
//
//        case 26:        // Note, in VER 1 PNet, we limit this to 3 nibbles
//            if (charCh >= '0' && charCh <= 'F')
//            {
//                stMach = 27;
//                newEqWord = (charCh - '0') << 8;
//            }
//            else stMach = 0;
//            break;
//
//        case 27:
//            if (charCh >= '0' && charCh <= 'F')
//            {
//                stMach = 28;
//                newEqWord += (charCh - '0') << 4;
//            }
//            else stMach = 0;
//            break;
//
//         case 28:
//            stMach = 0;
//            if (charCh >= '0' && charCh <= 'F')
//            {
//                newEqWord += (charCh - '0');
//                if (realityCheckEq(newEqWord))
//                {
//                    assignEqWord(childNodeNumber, newEqWord);
//                }
//                else
//                {
//                    putStr("sp");
//                    putChar('0' + pnetNodeNumber);
//                    putStr("ir");
//                }
//            }
//            break;
//
//        case 30:        // Reading T messages
//            if (charCh == '?') stMach = 31;
//            else stMach = 0;
//            break;
//
//        case 31:
//            stMach = 0;     // Terminus
//            if (charCh > '0' && charCh < '9')
//            {
//                childNodeNumber = charCh - '0';
//                respondTemperature(childNodeNumber);
//            }
//            break;
//
//        case 40:        // Reading H messages
//            if (charCh == '?') stMach = 41;
//            else stMach = 0;
//            break;
//
//        case 41:
//            stMach = 0;     // Terminus
//            if (charCh > '0' && charCh < '9')
//            {
//                childNodeNumber = charCh - '0';
//                respondRHumidity(childNodeNumber);
//            }
//            break;
//    case 60:            // Reading PROGmn
//            if (charCh == 'R') stMach = 61;
//            else stMach = 0;
//            break;
//
//        case 61:
//            if (charCh == 'O') stMach = 62;
//            else stMach = 0;
//            break;
//
//        case 62:
//            if (charCh == 'G') stMach = 63;
//            else stMach = 0;
//            break;
//
//        case 63:
//            stMach = 64;
//            if (charCh >= '0' && charCh < '9')  // Sic
//                 childNodeNumberOld = charCh - '0';
//            else stMach = 0;
//            break;
//
//        case 64:
//            stMach = 0;         // Terminus
//            if (charCh >= '0' && charCh < '9')  // Sic
//            {
//                 childNodeNumber = charCh - '0';
//                 assignNodeNumber(childNodeNumberOld, childNodeNumber);
//            }
//            break;
 

 // ---------------------------
//void respondStatus(byte ch)
//{
//    if (ch == pnetNodeNumber)
//    {
//       // putPrompt();
//        putStr("sk");
//        putChar('0' + pnetNodeNumber);
//        putChar('t');
//        if (!(childEqWord & CHILD_EQPT_TH_OUTSIDE)) putChar('0');
//        else if (childStatus & CHILD_TSEN_OKAY) putChar('+');
//        else putChar('-');
//
//        putChar('h');
//        if (!(childEqWord & CHILD_EQPT_TH_OUTSIDE)) putChar('0');
//        else if (childStatus & CHILD_HSEN_OKAY) putChar('+');
//        else putChar('-');
//
//        putChar('1');
//        if (childStatus & CHILD_K1_ON) putChar('+');
//        else putChar('-');
//
//        putChar('2');
//        if (childStatus & CHILD_K2_ON) putChar('+');
//        else putChar('-');
//        putChar('\r');
//    }
//    else return;
//}

//unsigned childEqWord = CHILD_EQPT_EXTFAN_K1 +  CHILD_EQPT_EXTFAN_K2 + CHILD_EQPT_TH_OUTSIDE;
    // Fake. WHat child reads locally on DIP sw on reset
//unsigned newEqWord;
//float childTemperature;
//float childRHumidity;
//unsigned childStatus = CHILD_TSEN_OKAY + CHILD_HSEN_OKAY;   // Fake.
    // TODO for child, check impossible combos

//void assignEqWord(byte childNodeNumber, unsigned newEqWord)
//{
//    if (childNodeNumber == pnetNodeNumber)
//    {
//        childEqWord = newEqWord;
//        //putPrompt();
//        putStr("spak");
//        putChar('0' + childNodeNumber);
//        putUns2Hex(childEqWord);
//        putChar('\r');
//       // putPrompt();
//    }
//    else return;
//}