/* File:   adc.c  Analog functions low and high level
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform: PIC32MX130F064B on DuraBlis Child board, ver 3
 * Created: 10 Jul 14
 */

#include <xc.h>
#include "DuraBlisChild.h"
#include "adc.h"
#include "serial.h"

#define NUM_SA   16

static unsigned adcUrConvert(byte chan);
static double adcMeanConvert(byte chan, byte opMode);

    // TODO set/clr error bits
void adcRHumid(byte opMode)
{
    extern double rhumidNow, rhumidCalFactor;
    double adcV;
        // Honeywell HIH5030
        // TODO Sensor has temperature dependence and slight hysteresis

    //if (opMode == ADC_LOQUACIOUS) putStr("\tRHumid hex vals:\r\n");

    adcV = adcMeanConvert(ANCH_RELHUM, ADC_SILENT);
    rhumidNow = 50 * adcV - 25;
    rhumidNow *= rhumidCalFactor;

    if (opMode == ADC_LOQUACIOUS)
    {
        putStr("\r\n\tRel humidity: ");
        sprintf(ioBfr, "%3.02f %% (%3.02fV)", rhumidNow, adcV);
        putStr(ioBfr);
        putStr("\n\r");
    }
}

    // Microchip MCP9700A
void adcTemper(byte opMode)
{
    extern double temperNowF, temperCalFactor;
    double adcV;

    if (opMode == ADC_LOQUACIOUS) putStr("\tTemp sen hex vals:\r\n");
       
    adcV = adcMeanConvert(ANCH_TEMPER, opMode);
    temperNowF = 180 * adcV - 58;
    temperNowF *= temperCalFactor;
}

    // Return mean voltage normalized to 3.3 V
    // Takes NUM_SA samples, throws out highest and lowest, compute mean.
double adcMeanConvert(byte chan, byte opMode)
{
    byte sa;
    double retVal = 0.0;
    unsigned uBfr[NUM_SA], samp, minSa = 0xFFFF, maxSa = 0;

    for (sa = 0; sa < NUM_SA; sa++)
    {
        delay_us(10);
        samp = adcUrConvert(chan);
        uBfr[sa] = samp;
        if (samp < minSa) minSa = samp;
        if (samp > maxSa) maxSa = samp;
    }
    
    for (sa = 0; sa < NUM_SA; sa++)
    {
        if (opMode == ADC_LOQUACIOUS)
        {
            putNib2Hex(uBfr[sa] >> 8);
            putNib2Hex(uBfr[sa] >> 4);
            putNib2Hex(uBfr[sa]);
            putStr("\r\n");
        }
        retVal += uBfr[sa];
    }

    retVal -= minSa;
    retVal -= maxSa;

    retVal /= (NUM_SA - 2);
    retVal = 3.3 * retVal / 1023;
    
        // DEB
//    sprintf(ioBfr, " %4.03f\t", retVal);
//    putStr(ioBfr);

    return(retVal);
}

unsigned adcUrConvert(byte chan)
{
    AD1CON1bits.SAMP = 0;       // End sampling & start conver
    AD1CHSbits.CH0NA = 0;       // Sample A Ch 0 neg input is Vrefl
    AD1CHSbits.CH0SA = chan;    // A mux <- chan
    AD1CSSL = 0;                // Write to scan buff 0

    AD1CON1bits.SAMP = 1;       // Start sampling
    delay_us(10);
    AD1CON1bits.SAMP = 0;
    while(!(AD1CON1bits.DONE)) ;    // Wait
    return(ADC1BUF0);
}