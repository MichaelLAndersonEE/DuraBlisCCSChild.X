/* File:   DuraBlisChild.h  Project wide defines and global variables
 * Author: Michael L Anderson
 * Contact: MichaelLAndersonEE@gmail.com
 * Platform:    PIC32MX130F064B on DuraBlisChild_v3 board
 * Created: 16 May 14
 */

#ifndef DURABLISCHILD_H
#define	DURABLISCHILD_H

#include <stdbool.h>    // To use bool type

#define SYS_FREQ	(25000000)  //  Primary external osc freq
#define IO_BFR_SIZE     30          // Volatile general IO buffer

    // Child status, which Parent may inquire
    // This must be semantically consistent with parent
#define	ST_LIQUID_DETECTED  0x80
#define ST_TSEN1_OKAY       0x40
#define ST_TSEN2_OKAY       0x20
#define ST_HSEN_OKAY        0x10
#define ST_K1_ON            0x01
#define ST_K2_ON            0x02

//#define CHILD_TSEN_OKAY         0x0001
//#define CHILD_TSEN_OVERRANGE    0x0002
//#define CHILD_TSEN_UNDERRANGE   0x0004
//#define CHILD_TSEN_NOISY        0x0008
//#define CHILD_HSEN_OKAY         0x0010
//#define CHILD_HSEN_OVERRANGE    0x0020
//#define CHILD_HSEN_UNDERRANGE   0x0040
//#define CHILD_HSEN_NOISY        0x0080
//#define CHILD_K1_ON             0x0100
//#define CHILD_K2_ON             0x0200
//#define	CHILD_LIQUID_DETECTED   0x0400

    // EQQ word, 12 bit from child
//#define CHILD_EQPT_TH_OUTSIDE       0x001
//#define CHILD_EQPT_TH_INTFAN        0x002
//#define CHILD_EQPT_DEHUM_K1         0x004
//#define CHILD_EQPT_EXTFAN_K1        0x008
//#define CHILD_EQPT_HUMIDIFIER_K1    0x010
//#define CHILD_EQPT_DEHUM_K2         0x020
//#define CHILD_EQPT_EXTFAN_K2        0x040
//#define CHILD_EQPT_HUMIDIFIER_K2    0x080
//#define CHILD_EQPT_LIQUIDSENSOR     0x100

//#define PARENT_EQPT_HEATER_K1       0x1000  // These get ORed with children EQQ
//#define PARENT_EQPT_HEATER_K2       0x2000
//#define PARENT_EQPT_AIRCON_K1       0x4000
//#define PARENT_EQPT_AIRCON_K2       0x8000

    // Time read modes
#define TIME_UPDATE             0x01
//#define TIME_NEW_MINUTE         0x02
//#define TIME_NEW_SECOND         0x03
#define TIME_LOQUACIOUS         0x04
#define TIMEOUT_HUMAN           0xAAAA   // Related factor
#define TIMEOUT_PNET            0x2222

    /**** Hardware mapping definitions...   ****/

    // Analog channels
#define ANCH_TEMPER     0   // AN0 U2.2 = RA0
#define ANCH_RELHUM     1   // AN1 U2.2 = RA1
#define ANCH_FLOOD      4   // AN4 U2.6 = RB2
#define ANCH_TEMPER2    2   // AN2 U2.4 = RB0

    // Hardware lines
#define NODEID_1        PORTBbits.RB3       // i U2.7
#define NODEID_2        PORTBbits.RB4       // i U2.11
#define NODEID_4        PORTBbits.RB5       // i U2.14
#define NODEID_8        PORTBbits.RB12      // i U2.23
#define LED_GREEN       LATAbits.LATA4      // o0 U2.4
#define COMM_SHDN_n     LATBbits.LATB9      // o1 U2.18
#define SMEM_CS_n       LATBbits.LATB10     // o1 U2.21
#define RELAY1          LATBbits.LATB15     // o1 U2.26
#define RELAY2          LATBbits.LATB13     // o1 U2.24

//#define SPIDATO         LATBbits.LATB8      // DEB
//#define SPIDATI         LATBbits.LATB11     // DEB
//#define SPICLK          LATBbits.LATB14     // DEB

typedef unsigned char byte;
extern char ioBfr[];

//void delay_ms(unsigned t);        // Dumb delay fcn.
void delay_us(unsigned t);        // Dumb delay fcn.

#endif
